package SleepyBot;

import java.util.ArrayList;
import java.util.Random;
import battlecode.common.*;


/**
 * I am having some issues with this contest.  The first thing to keep in mind is that keeping global data is a bitch in BattleCode.
 * 
 * @author Jamie O
 *
 */

public class RobotPlayer
{

	/*
	 * 	static RobotController rc;
	static Team myTeam;
	static Team enemyTeam;
	static int myRange;
	static Random rand;
	static Direction[] directions = {Direction.NORTH, Direction.NORTH_EAST, Direction.EAST, Direction.SOUTH_EAST, Direction.SOUTH, Direction.SOUTH_WEST, Direction.WEST, Direction.NORTH_WEST};
	 */
	
	//Environment variables for keeping track of the game state.
	
	private static Team myTeam;
	private static Team enemyTeam;
	private static int myRange;
	private static Random rand;
			
	
	

	
	
	/**
	 * run()
	 * This is the main control loop for robots.  This is run by all robots, so we need code for differentiating between who is calling.
	 * @param rc:  a Robot Controller provided by the client.
	 */
	public static void run(RobotController rc)
	{
		rand = new Random(rc.getID());
		myTeam = rc.getTeam();
		enemyTeam = myTeam.opponent();
		
		//myRobots = rc.senseNearbyRobots(999999, myTeam);
		

		//The stat collector gives us what buildings exist and the quantity of units.  We pass it into
		//The agents in case they need to make decisions based on unit existence.
		StatCollector teamStats = new StatCollector(rc);
		System.out.println(teamStats);
		
		
		//This is the main control loop for robots.  This is run by all robots, so we need code inside to
		//differentiate between who is calling.
		while(true)
		{
			
			if (rc.isCoreReady() )
			{
				//If we are the headquarters, call the HQ Agent for behavior.
				if (rc.getType() == RobotType.HQ)
				{
					HQAgent(rc, teamStats);
				}
				
				//If we are a beaver, call the Beaver Agent for behavior.
				if (rc.getType() == RobotType.BEAVER)
				{
					//aStarNextStep( rc, rc.senseEnemyHQLocation() );
					BeaverAgent(rc, teamStats);
				}
				
				//If we are a barracks, call the Barracks Agent for behavior.
				if (rc.getType() == RobotType.BARRACKS)
				{
					BarracksAgent(rc, teamStats);
				}
				
				if (rc.getType() == RobotType.TOWER)
				{
					TowerAgent(rc, teamStats);
				}
				
			}
			

		rc.yield();
		}
		
		
	}
	
	
	
	/**
	 * HQAgent()
	 * Determines the behavior for an HQ unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void HQAgent(RobotController rc, StatCollector teamStats)
	{
		
		//If we can currently build a beaver...
		if (rc.canSpawn(Direction.NORTH, RobotType.BEAVER) && rc.isCoreReady())
		{
			//Make a beaver to the north.
			try
			{
				rc.spawn(Direction.NORTH, RobotType.BEAVER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		//MapLocation?
	}


	
	/**
	 * BeaverAgent()
	 * Determines the behavior for a Beaver unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void BeaverAgent(RobotController rc, StatCollector teamStats)
	{
		
		
		//rule 1:  If no barracks exists, we must build one.
		if (rc.canBuild(Direction.NORTH, RobotType.BARRACKS) && rc.isCoreReady())
		{
			try
			{
				rc.build(Direction.NORTH, RobotType.BARRACKS);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		
		}
		
		//rule 2:  If there is ore under our feet, we must mine it.
		if (rc.senseOre(rc.getLocation()) > 1 && rc.isCoreReady() && rc.canMine())
		{
			
			try
			{
				rc.mine();
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
	}

	
	
	/**
	 * BarracksAgent()
	 * Determines the behavior for a Barracks unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void BarracksAgent(RobotController rc, StatCollector teamStats)
	{
		
		//rule 1:  If we can build a soldier, do so.
		if (rc.canSpawn(Direction.NORTH, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.NORTH_EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH_EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.NORTH_WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH_WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH_WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH_WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH_EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH_EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
	}
	
	
	/**
	 * TowerAgent()
	 * Determines the behavior for a Tower unit.
	 * @param rc
	 */
	public static void TowerAgent(RobotController rc, StatCollector teamStats)
	{
		//If the tower can shoot
		if (rc.isWeaponReady() )
		{
			//Build a list of enemies that are within our attack range.
			RobotInfo[] enemies = rc.senseNearbyRobots(RobotType.TOWER.attackRadiusSquared, enemyTeam);
			
			//If there are enemies in our attack range, shoot the first of them.
			if (enemies.length > 0) {
				try
				{
					rc.attackLocation(enemies[0].location);
				}
				catch (GameActionException e)
				{
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	
	/**
	 * THIS SECTION IS ON THE DFS THAT WILL BE CONVERTED TO A STAR ONCE MY DUMB SELF HAS FIXED IT. 
	 */
	
	public static ArrayList<MapLocation> DFS(MapLocation source, MapLocation destination)
	{
		
		//Make the path list to return.
		ArrayList<MapLocation> pointList = new ArrayList<MapLocation>();
		
		//If the source and destination aren't the same, we need to start routing.
		if ( !(source.x == destination.x && source.y == destination.y) )
		{
			//Add the route to the 
			pointList = recursiveDFS(source, destination)
		}
		
		return pointList;
	}
	
	/**
	 * aStarNextStep
	 * Because the robots cannot save state information as their turns pass, we have to recalculate their path each turn.
	 * @param rc:  The Robot Controller that is requesting pathing info
	 * @param destination:  The MapLocation the robot wants to reach.
	 * @return:  The MapLocation the robot should move to next.
	 */
	public static MapLocation aStarNextStep(RobotController rc, MapLocation destination)
	{
		MapLocation start = rc.getLocation();
		
		ArrayList<MapLocation> neighbors = new ArrayList<MapLocation>();
		
		int x  = 0;
		int y = 0;
		MapLocation loc;
		
		
		//Test to see if the north is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.NORTH) )
			{
				x = rc.getLocation().x;
				y = rc.getLocation().y - 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the northeast is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.NORTH_EAST) )
			{
				x = rc.getLocation().x + 1;
				y = rc.getLocation().y - 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the northwest is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.NORTH_WEST) )
			{
				x = rc.getLocation().x - 1;
				y = rc.getLocation().y - 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the west is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.WEST) )
			{
				x = rc.getLocation().x - 1;
				y = rc.getLocation().y;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the east is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.EAST) )
			{
				x = rc.getLocation().x + 1;
				y = rc.getLocation().y;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the south is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.SOUTH) )
			{
				x = rc.getLocation().x;
				y = rc.getLocation().y + 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the south is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.SOUTH_EAST) )
			{
				x = rc.getLocation().x + 1;
				y = rc.getLocation().y + 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		//Test to see if the south is open.  If so, add it to the neighbors list.
		if ( rc.canMove(Direction.SOUTH_WEST) )
			{
				x = rc.getLocation().x - 1;
				y = rc.getLocation().y + 1;
				loc = new MapLocation(x, y);
				neighbors.add(loc);
			}
		
		System.out.println("I am at location:" + start.x + "," + start.y + "\nMy neighbors are:  " );
						
		//I need to see how the x and y coordinates work.
		for (int i = 0; i < neighbors.size(); i++)
		{
			System.out.println( neighbors.get(i).x + "," + neighbors.get(i).y );
		}
		
	
		
		
		return null;
	}
	
	


}//end of class
	

