package SleepyBot;

import battlecode.common.*;

public class StatCollector
{
	
	//Flags for if we've built each building.
	private boolean aerospaceLabBuilt = false;
	private boolean barracksBuilt = false;
	private boolean handWashStationBuilt = false;
	private boolean helipadBuilt = false;
	private boolean minerFactoryBuilt = false;
	private boolean supplyDepotBuilt = false;
	private boolean tankFactoryBuilt = false;
	private boolean technologyInstituteBuilt = false;
	private boolean trainingFieldBuilt = false;
	
	
	
	//Counts of the number of units we have on the field.
	private int basherCount = 0;
	private int beaverCount = 0;
	private int commanderCount = 0;
	private int droneCount = 0;
	private int launcherCount = 0;
	private int minerCount = 0;
	private int soldierCount = 0;
	private int tankCount = 0;
	private int towerCount = 0;
	
	public StatCollector(RobotController rc)
	{
		
		RobotInfo[] myRobots = rc.senseNearbyRobots(999999, rc.getTeam());
		
		for (int i = 0; i < myRobots.length; i++)
		{
			RobotType botType = myRobots[i].type;

			
			

			switch (botType)
			{
			
			//First, search for buildings.
			case AEROSPACELAB:
			{
				aerospaceLabBuilt = true;
				break;
			}
			case BARRACKS:
			{
				barracksBuilt = true;
				break;
			}
			case HANDWASHSTATION:
			{
				handWashStationBuilt = true;
				break;
			}
			case HELIPAD:
			{
				helipadBuilt = true;
				break;
			}
			case MINERFACTORY:
			{
				minerFactoryBuilt = true;
				break;
			}
			case SUPPLYDEPOT:
			{
				supplyDepotBuilt = true;
				break;
			}
			case TANKFACTORY:
			{
				tankFactoryBuilt = true;
				break;
			}
			case TECHNOLOGYINSTITUTE:
			{
				technologyInstituteBuilt = true;
				break;
			}
			case TRAININGFIELD:
			{
				trainingFieldBuilt = true;
				break;
			}
			
		
			//Now, count the units we have on the table.
			case BASHER:
			{
				basherCount++;
				break;
			}
			case BEAVER:
			{
				beaverCount++;
				break;
			}
			case COMMANDER:
			{
				commanderCount++;
				break;
			}
			case DRONE:
			{
				droneCount++;
				break;
			}
			case LAUNCHER:
			{
				launcherCount++;
				break;
			}
			case MINER:
			{
				minerCount++;
				break;
			}
			case SOLDIER:
			{
				soldierCount++;
				break;
			}
			case TANK:
			{
				tankCount++;
				break;
			}
			case TOWER:
			{
				towerCount++;
				break;
			}
			
			
			default:
			{
				break;
			}
			
			}//end switch
			
			
		}//end for loop
		
	}//end constructor

	public boolean isAerospaceLabBuilt() {
		return aerospaceLabBuilt;
	}

	public boolean isBarracksBuilt() {
		return barracksBuilt;
	}

	public boolean isHandWashStationBuilt() {
		return handWashStationBuilt;
	}

	public boolean isHelipadBuilt() {
		return helipadBuilt;
	}

	public boolean isMinerFactoryBuilt() {
		return minerFactoryBuilt;
	}

	public boolean isSupplyDepotBuilt() {
		return supplyDepotBuilt;
	}

	public boolean isTankFactoryBuilt() {
		return tankFactoryBuilt;
	}

	public boolean isTechnologyInstituteBuilt() {
		return technologyInstituteBuilt;
	}

	public boolean isTrainingFieldBuilt() {
		return trainingFieldBuilt;
	}

	public int getBasherCount() {
		return basherCount;
	}

	public int getBeaverCount() {
		return beaverCount;
	}

	public int getCommanderCount() {
		return commanderCount;
	}

	public int getDroneCount() {
		return droneCount;
	}

	public int getLauncherCount() {
		return launcherCount;
	}

	public int getMinerCount() {
		return minerCount;
	}

	public int getSoldierCount() {
		return soldierCount;
	}

	public int getTankCount() {
		return tankCount;
	}

	public int getTowerCount() {
		return towerCount;
	}

	

	
	

}
