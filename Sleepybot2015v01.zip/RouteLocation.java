package SleepyBot;

import battlecode.common.*;


/**
 * A RouteLocaiton is used for pathing, and includes a map location and the location we were previously at.
 * @author Jamie O
 *
 */

public class RouteLocation
{
	public MapLocation mapTile;
	public MapLocation previous;
	
	public RouteLocation(MapLocation mapTile, MapLocation previous)
	{
		this.mapTile = mapTile;
		this.previous = previous;
	}

	public RouteLocation(MapLocation mapTile)
	{
		this.mapTile = mapTile;
	}

	public RouteLocation()
	{
	}

		
	public MapLocation getMapTile()
	{	return mapTile;	}

	public void setMapTile(MapLocation mapTile)
	{	this.mapTile = mapTile;	}

	public MapLocation getPrevious()
	{	return previous;	}

	public void setPrevious(MapLocation previous)
	{	this.previous = previous;	}
	
	
	
	
}
