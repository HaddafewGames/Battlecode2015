package SleepyBot;

public class MapTools {

}
