package SleepyBot;

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Stack;

import battlecode.common.*;


/**
 * I am having some issues with this contest.  The first thing to keep in mind is that keeping global data is a bitch in BattleCode.
 * 
 * @author Jamie O
 *
 */

public class RobotPlayer
{

	/*
	 * 	static RobotController rc;
	static Team myTeam;
	static Team enemyTeam;
	static int myRange;
	static Random rand;
	static Direction[] directions = {Direction.NORTH, Direction.NORTH_EAST, Direction.EAST, Direction.SOUTH_EAST, Direction.SOUTH, Direction.SOUTH_WEST, Direction.WEST, Direction.NORTH_WEST};
	 */
	
	//Environment variables for keeping track of the game state.
	
	private static Team myTeam;
	private static Team enemyTeam;
	private static int myRange;
	private static Random rand;
	private static RouteLocationGraph route;

	private static boolean canMove; // flagged false if our path is failing.
	
	/**
	 * run()
	 * This is the main control loop for robots.  This is run by all robots, so we need code for differentiating between who is calling.
	 * @param rc:  a Robot Controller provided by the client.
	 */
	public static void run(RobotController rc)
	{
		rand = new Random(rc.getID());
		myTeam = rc.getTeam();
		enemyTeam = myTeam.opponent();
		
		route = new RouteLocationGraph();
		canMove = false;
		
		//myRobots = rc.senseNearbyRobots(999999, myTeam);
		


		
		//This is the main control loop for robots.  This is run by all robots, so we need code inside to
		//differentiate between who is calling.
		while(true)
		{
			
			//Update the game team stats so the agent knows how many buildings / units exist.
			//The agents in case they need to make decisions based on unit existence.
			StatCollector teamStats = new StatCollector(rc);
			
			
			if (rc.isCoreReady() )
			{
				//If we are the headquarters, call the HQ Agent for behavior.
				if (rc.getType() == RobotType.HQ)
				{
					HQAgent(rc, teamStats);
				}
				
				//If we are a beaver, call the Beaver Agent for behavior.
				if (rc.getType() == RobotType.BEAVER)
				{
					//aStarNextStep( rc, rc.senseEnemyHQLocation() );
					BeaverAgent(rc, teamStats);
				}
				
				//If we are a barracks, call the Barracks Agent for behavior.
				if (rc.getType() == RobotType.BARRACKS)
				{
					BarracksAgent(rc, teamStats);
				}
				
				if (rc.getType() == RobotType.TOWER)
				{
					TowerAgent(rc, teamStats);
				}
				
				if (rc.getType() == RobotType.SOLDIER)
				{
					SoldierAgent(rc, teamStats);
				}
				
			}
			

		rc.yield();
		}
		
		
	}
	
	
	
	/**
	 * HQAgent()
	 * Determines the behavior for an HQ unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void HQAgent(RobotController rc, StatCollector teamStats)
	{
		
		//If we can currently build a beaver...
		if (rc.canSpawn(Direction.NORTH, RobotType.BEAVER) && rc.isCoreReady())
		{
			//Make a beaver to the north.
			try
			{
				rc.spawn(Direction.NORTH, RobotType.BEAVER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}

	}


	
	/**
	 * BeaverAgent()
	 * Determines the behavior for a Beaver unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void BeaverAgent(RobotController rc, StatCollector teamStats)
	{
		
		
		//rule 1:  If no barracks exists, we must build one.
		if (rc.canBuild(Direction.NORTH, RobotType.BARRACKS) && rc.isCoreReady())
		{
			try
			{
				rc.build(Direction.NORTH, RobotType.BARRACKS);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		
		}
		
		//rule 2:  If there is ore under our feet, we must mine it.
		if (rc.senseOre(rc.getLocation()) > 1 && rc.isCoreReady() && rc.canMine())
		{
			
			try
			{
				rc.mine();
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
	}

	
	
	/**
	 * BarracksAgent()
	 * Determines the behavior for a Barracks unit.
	 * @param rc:  The Robot Controller to act on.
	 */
	public static void BarracksAgent(RobotController rc, StatCollector teamStats)
	{
		
		//rule 1:  If we can build a soldier, do so.
		if (rc.canSpawn(Direction.NORTH, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		/*if (rc.canSpawn(Direction.NORTH_EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH_EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.NORTH_WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.NORTH_WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH_WEST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH_WEST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		
		if (rc.canSpawn(Direction.SOUTH_EAST, RobotType.SOLDIER) && rc.isCoreReady())
		{
			try
			{
				rc.spawn(Direction.SOUTH_EAST, RobotType.SOLDIER);
			}
			catch (GameActionException e)
			{
				e.printStackTrace();
			}
		}
		*/
		
	}
	
	
	/**
	 * TowerAgent()
	 * Determines the behavior for a Tower unit.
	 * @param rc
	 */
	public static void TowerAgent(RobotController rc, StatCollector teamStats)
	{
		//If the tower can shoot
		if (rc.isWeaponReady() )
		{
			//Build a list of enemies that are within our attack range.
			RobotInfo[] enemies = rc.senseNearbyRobots(RobotType.TOWER.attackRadiusSquared, enemyTeam);
			
			//If there are enemies in our attack range, shoot the first of them.
			if (enemies.length > 0) {
				try
				{
					rc.attackLocation(enemies[0].location);
				}
				catch (GameActionException e)
				{
					e.printStackTrace();
				}
			}
		}
		
	}


	public static void SoldierAgent(RobotController rc, StatCollector teamStats)
	{
		//If there are enemies in range, shoot them.
		if (rc.isWeaponReady() )
		{
			System.out.println("Weapon is ready.");
			//Build a list of enemies that are within our attack range.
			RobotInfo[] enemies = rc.senseNearbyRobots(RobotType.SOLDIER.attackRadiusSquared, enemyTeam);
			
			//If there are enemies in our attack range, shoot the first of them.
			if (enemies.length > 0 && rc.canAttackLocation(enemies[0].location)) {
				try
				{
					System.out.println("There are enemies to attack");
					rc.attackLocation(enemies[0].location);
					return;
				}
				catch (GameActionException e)
				{
					e.printStackTrace();
				}
			}
		}
		
		
		
		//Rule 2:  If there are no enemies nearby, advance.
	
		System.out.println("Rule 2");
		
		MapLocation enemyCore = null;
		Stack<RouteLocation> routeToEnemyBase = null;
				
		System.out.println("Creating a path.");
		enemyCore = rc.senseEnemyHQLocation();
		routeToEnemyBase = route.aStarStart(rc, rc.getLocation(), enemyCore);
		System.out.println("The size of the route is:" + routeToEnemyBase.size());
		routeToEnemyBase.pop();
		canMove = true;

		
		System.out.println("Preparing to Move.");
		


		try
		{
			if (routeToEnemyBase == null) {System.out.println("The route is empty"); }
			System.out.println("The size of the route is: " + routeToEnemyBase.size());
			MapLocation nextTile = routeToEnemyBase.peek().mapTile;
			Direction moveDirection = MapTools.findDirection(rc.getLocation(), nextTile);
			
			System.out.println("ATTEMPTING TO MOVE to the " + moveDirection);
			
			if (rc.canMove(moveDirection))
			{
				System.out.println("Marching forward.");
				routeToEnemyBase.pop();
				//MapLocation moveDestination = routeToEnemyBase.pop().mapTile;
				//System.out.println("Moving to" + moveDestination.x + "," + moveDestination.y);
				try
				{
					
					rc.move(moveDirection);
				}
				catch (GameActionException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			//If we are stuck and cannot move, shake our way out.
			else
			{
				System.out.println("Pathing failed.");
				rc.move(MapTools.randomDirection());
			}
			
		}
		catch (Exception e)
		{
			System.out.println("out of bounds exception.");
		}
		

		
	}
	


}//end of class
	

