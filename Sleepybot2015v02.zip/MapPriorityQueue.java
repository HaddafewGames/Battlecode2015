package SleepyBot;

import java.util.ArrayList;

public class MapPriorityQueue
{
	private ArrayList<RouteLocation> routeList;
		
	
	public int size()
	{
		return routeList.size();
	}
	
	public MapPriorityQueue()
	{
		routeList = new ArrayList<RouteLocation>();
	}
	
	public void insert(RouteLocation rl, double c)
	{
		//System.out.println("In insert.");
		
		rl.cost = c;
		
		//If the list is empty or the cost is less than the first element of the list, put it at the front.
		if (routeList.isEmpty())
		{
			routeList.add(rl);
		}
		else if  (c <= routeList.get(0).cost)
		{
			routeList.add(0,rl);
		}
		//If the cost is larger than the last element, add it to the back.
		else if (c >= routeList.get(routeList.size()-1).cost )
		{
			routeList.add(rl);
		}

		//Otherwise, the cost is between two values; insert the element between those two.
		else
		{
			int last = routeList.size()-1;
			int first = 0;
			int middle;

			//Hobo binary search
			while (true)
			{
				 middle = (last + first / 2);
				
				//System.out.println("First is: " + first + " Last is: " + last + " Middle is:  " + middle);
				if ( last - first == 0 )
				{
					routeList.add(first, rl);
					break;
				}
				if (last < first)
				{
					routeList.add(last, rl);
					break;
				}
				
			
				if (c == routeList.get(middle).cost )
				{
					routeList.add(middle, rl);
				}
				else if (c < routeList.get(middle).cost)
				{
					last = middle-1;
				}
				else	
				{
					first = middle + 1;
				}
			}
			
		}
		
		//System.out.println("Leaving insert.");
	}
	
	
	/**
	 * update()
	 * We use this function when we need to change the value of, or add, an element to the pq.  If the element is found, we remove it, change the distance value, and re-insert it in the proper place.
	 * @param rc
	 * @param c
	 */
	public void update(RouteLocation rc, double c)
	{
		//System.out.println("In update.");
		
		boolean found = false;
		
		for (int i = 0; i < routeList.size(); i++)
		{
			if ( routeList.get(i).equals(rc) )
			{
				routeList.remove(i);
				found = true;
			}
		}
		
		if (found == false)
		{
			insert(rc, c);
		}
		
		//System.out.println("Leaving update");
		
	}
	
	
	//Show the first value, but don't remove it.
	public RouteLocation peek()
	{
		return routeList.get(0);
	}
	
	//Remove the frst value from the MapPQ
	public RouteLocation pop()
	{
		RouteLocation rl = routeList.get(0);
		
		routeList.remove(0);
				
		return rl;
	}
	

}
