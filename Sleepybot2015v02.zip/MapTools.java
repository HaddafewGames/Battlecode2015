package SleepyBot;
import java.util.Random;

import battlecode.common.*;

public class MapTools
{
	/**
	 * Determine if two points are the same by checking their x and y values.
	 * @param a:  source location
	 * @param b:  destination location
	 * @return:  true if the same, false otherwise.
	 */
	public static boolean areEqual(MapLocation a, MapLocation b)
	{
		if (a.x == b.x && a.y == b.y)
		{
			return true;
		}
		return false;
	}

	/**
	 * Return the euclidean distance between two map locations.
	 * @param a:  source location
	 * @param b:  destination location
	 * @return:  the distance as a decimal value
	 */
	public static double distance(MapLocation a, MapLocation b)
	{
		double xDim = Math.pow( (b.x - a.x), 2);
		double yDim = Math.pow( (b.y - a.y), 2);
		
		return Math.sqrt(xDim + yDim);
	}
	
	public static Direction randomDirection()
	{
		Random r = new Random();
		
		int value = r.nextInt(8);
		
		switch (value)
		{
		case 0:
		{
			return Direction.NORTH;
		}
		case 1:
		{
			return Direction.NORTH_EAST;
		}
		case 2:
		{
			return Direction.NORTH_WEST;
		}
		case 3:
		{
			return Direction.SOUTH;
		}
		case 4:
		{
			return Direction.SOUTH_EAST;
		}
		case 5:
		{
			return Direction.SOUTH_WEST;
		}
		case 6:
		{
			return Direction.WEST;
		}
		case 7:
		{
			return Direction.EAST;
		}
		default:
		{
			return Direction.NORTH;
		}
	}//end switch
		
	}

	
	//Here we convert adjacent x,y locations into a direction signifying the move from a to b.
	public static Direction findDirection(MapLocation a, MapLocation b)
	{
		System.out.println("The robot is at " + a + " and must get to " + b);
		
		
		if (a.y - b.y == 1 && a.x - b.x == 1)
			return Direction.NORTH_WEST;
		if (a.y - b.y == 1 && a.x - b.x == -1)
			return Direction.NORTH_EAST;
		if (a.y - b.y == -1 && a.x - b.x == 1)
			return Direction.SOUTH_WEST;
		if (a.y - b.y == -1 && a.x - b.x == -1)
			return Direction.SOUTH_EAST;
		
		
		if (a.y - b.y == 1)
			return Direction.NORTH;
		if (a.y - b.y == -1)
			return Direction.SOUTH;
		if (a.x - b.x == 1)
			return Direction.WEST;
		if (a.x - b.x == -1)
			return Direction.EAST;
		
		
		return Direction.NONE;
	}
}
