package SleepyBot;

import java.util.ArrayList;
import java.util.Stack;

import battlecode.common.Direction;
import battlecode.common.MapLocation;
import battlecode.common.RobotController;
import battlecode.common.TerrainTile;

public class RouteLocationGraph
{
	public ArrayList<RouteLocation> searchTiles;
	
	public RouteLocationGraph()
	{
		searchTiles = new ArrayList<RouteLocation>();
	}
	
	public void addNode(RouteLocation rl)
	{
		searchTiles.add(rl);
	}
	
	public void addNode(MapLocation ml)
	{
		RouteLocation rl = new RouteLocation(ml);
		searchTiles.add(rl);
	}
	

	/*
	 * Get the index in the adjacency list of a node, if it exists in the list already.  If not, return -1.
	 * */
	public int indexOf(RouteLocation rl)
	{
		for (int i = 0; i < searchTiles.size(); i++)
		{
			if ( searchTiles.get(i).equals(rl) )
			{
				return i;
			}
		
		}
		return -1;
	}
	
	
	//Because the game does not give us access to the map itself, we can only rely on what our robot senses.
	//Because of this, we cannot build a matrix representation of the map; we have to build an adjacency list
	//representation of the map.  We are operating with partial information.
	public Stack<RouteLocation> aStarStart(RobotController rc, MapLocation source, MapLocation destination)
	{
		
			
		//create a stack for the solution path.
		Stack<RouteLocation> pathStack = null;
		
		//create a new search graph to explore.
		RouteLocationGraph searchSpace = new RouteLocationGraph();
		searchSpace.addNode(source);
	
		RouteLocation rlSource = new RouteLocation(source);
		RouteLocation rlDestination = new RouteLocation(destination);
		int tilesSoFar = 0;

		MapPriorityQueue successors = new MapPriorityQueue();
		
		
		Stack<RouteLocation> solution = aStarSearch(rc, rlSource, rlDestination, tilesSoFar, pathStack, searchSpace, successors);
		return solution;
	}
	

	private Stack<RouteLocation> aStarSearch(RobotController rc, RouteLocation source, RouteLocation destination, int tilesSoFar, Stack<RouteLocation> pathStack, RouteLocationGraph searchSpace, MapPriorityQueue successors)
	{

				
		do 				
		{
			
					
			source.explored = true;
			
			//If we are where we intend to be, return the solution path.
			if ( source.equals(destination) || tilesSoFar > 3)
				{
					//Create the solution plan by traversing backwards along the constructed graph.
					pathStack = new Stack<RouteLocation>();
					RouteLocation pointer = source;
					while (pointer != null)
					{
						pathStack.add(pointer);
						pointer = pointer.previous;
					}
			
				return pathStack;
				}
			
			if (pathStack != null) return pathStack;
			
			
			
			
			//We made the MapPQ structure to create a priority queue that orders these objects by the heuristic
			//cost we created.

			
			//Establish what tiles are in the directions.
			MapLocation north = source.mapTile.add(Direction.NORTH);
			MapLocation south = source.mapTile.add(Direction.SOUTH);
			MapLocation east = source.mapTile.add(Direction.EAST);
			MapLocation west = source.mapTile.add(Direction.WEST);
			MapLocation northeast = source.mapTile.add(Direction.NORTH_EAST);
			MapLocation northwest = source.mapTile.add(Direction.NORTH_WEST);
			MapLocation southeast = source.mapTile.add(Direction.SOUTH_EAST);
			MapLocation southwest = source.mapTile.add(Direction.SOUTH_WEST);

		
			//If we can move in a direction, check to add it to the successors PQ.
			if (rc.senseTerrainTile(north) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, north, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(south) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, south, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(east) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, east, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(west) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, west, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(northeast) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, northeast, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(northwest) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, northwest, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(southeast) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, southeast, destination, tilesSoFar, searchSpace, successors);
			}
			if (rc.senseTerrainTile(southwest) == TerrainTile.NORMAL)
			{
				successors = addMove(rc, source, southwest, destination, tilesSoFar, searchSpace, successors);
			}
				
			
			
			
			source = successors.pop();
			tilesSoFar++;
					
		} while (successors.size() > 0);
		
		return null;
		
	}

	
	
	
	
	private MapPriorityQueue addMove(RobotController rc, RouteLocation source, MapLocation checkTile, RouteLocation dest, int tilesSoFar, RouteLocationGraph searchSpace, MapPriorityQueue successors)
	{
				
		RouteLocation rl = new RouteLocation(checkTile);
		double cost = tilesSoFar + MapTools.distance (checkTile, dest.mapTile);
		
		//See if the location to the north of us is in the search space already.
		int searchIndex = searchSpace.indexOf(rl);
		
		if (rc.senseTerrainTile(checkTile) == TerrainTile.NORMAL)
		{
			rl = new RouteLocation(checkTile);
			cost = tilesSoFar + MapTools.distance (checkTile, dest.mapTile);
			
			
			
			//If it is not, add it, with this tile as the source, and the current calculated cost as the travel cost.
			if ( searchIndex == -1)
			{
				rl.cost = cost;
				rl.setPrevious(source);
				searchSpace.addNode(rl);
			}
			else
			//If it is, see if the cost is lower.
			{
				//If so, update the cost.
				if (cost < rl.cost)
				{
					searchSpace.searchTiles.get(searchIndex).setPrevious(source);
					searchSpace.searchTiles.get(searchIndex).cost = cost;
				}
				
			}
			
			
			//Add the element to the list of successors, unless we have already been there.
			if (rl.explored == false)
				{
					successors.update(rl, cost);
				}
		}
		
		
		return successors;
	}
	
	
	
	
	
	
}
