package SleepyBot;

import battlecode.common.*;


/**
 * A RouteLocaiton is used for pathing, and includes a map location and the location we were previously at.
 * @author Jamie O
 *
 */

public class RouteLocation
{
	public MapLocation mapTile;
	public RouteLocation previous;
	public boolean explored;
	public double cost;
	
	public RouteLocation(MapLocation mapTile, RouteLocation previous)
	{
		super();
		this.mapTile = mapTile;
		this.previous = previous;
	}

	public RouteLocation(MapLocation mapTile)
	{
		super();
		this.mapTile = mapTile;
	}
		
	public RouteLocation()
	{
		cost = 99999;
		explored = false;
		previous = null;
		mapTile = null;
	}

	public boolean equals(Object o)
	{
		
		RouteLocation rt = RouteLocation.class.cast(o);
		
		if ( MapTools.areEqual(mapTile, rt.mapTile) )
			return true;
		
		return false;
	}

	
	
	
		
	public MapLocation getMapTile()
	{	return mapTile;	}

	public void setMapTile(MapLocation mapTile)
	{	this.mapTile = mapTile;	}

	public RouteLocation getPrevious()
	{	return previous;	}

	public void setPrevious(RouteLocation previous)
	{	this.previous = previous;	}
	
}
